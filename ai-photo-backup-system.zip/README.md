# AI-Enhanced Photo Backup System

A Python desktop application that backs up photo collections while detecting exact duplicates, near-duplicates, and blurry images. The project is designed for photographers who manage large batches of photos, including RAW files.

## Overview

Photographers often copy hundreds of images from memory cards, external drives, or camera folders. During this process, files can be duplicated, copied while still locked by another program, or mixed with blurry/low-quality images.

This application solves that workflow problem by combining local backup automation with lightweight computer vision checks.

## Key Features

- Recursive folder scanning and monitoring using Watchdog
- Desktop GUI built with Tkinter
- Background worker queues for smoother processing
- Exact duplicate detection using SHA-256 hashing
- Persistent duplicate index using SQLite
- Near-duplicate detection using perceptual hashing for non-RAW images
- Blur detection using OpenCV Laplacian variance
- RAW image support for formats such as `.ARW`, `.CR2`, `.CR3`, `.NEF`, `.RAF`, and `.DNG`
- File-lock handling for images still being copied or used by another process
- Atomic copy method to reduce risk of partial/corrupted backups
- CSV logging for backup actions, errors, duplicate results, blur scores, and processing time
- Real-time activity log and recent-files table in the interface

## Technologies Used

- Python
- Tkinter
- OpenCV
- Pillow
- ImageHash
- SQLite
- Watchdog
- CSV logging
- SHA-256 hashing

## Project Structure

```text
app/
├── core/
│   ├── backup_app.py
│   └── watchdog_handler.py
├── data/
│   ├── csv_logger.py
│   └── db.py
├── ui/
│   └── app_ui.py
├── utils/
│   ├── constants.py
│   └── system.py
└── main.py
```

## How It Works

1. The user selects a source folder and a backup folder.
2. The app scans existing files and monitors for new or modified images.
3. Each image is placed into a processing queue.
4. The system waits until the file is ready, reducing Windows file-lock issues.
5. SHA-256 hashing checks whether the exact file already exists in the backup index.
6. New files are copied safely using an atomic copy process.
7. Non-RAW images are analysed for blur and near-duplicate similarity.
8. Results are shown in the GUI and saved to CSV/SQLite for later review.

## How to Run

Clone the repository:

```bash
git clone https://github.com/Ingsamangdembe/ai-photo-backup-system.git
cd ai-photo-backup-system
```

Create and activate a virtual environment:

```bash
python -m venv venv
venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Run the application:

```bash
python -m app.main
```

## Notes

Runtime files such as `backup_index.db` and `backup_log.csv` are generated locally when the app runs. They are intentionally excluded from GitHub because they may contain local file paths or personal usage data.

## Future Improvements

- Add screenshots and demo video
- Add filtering/export options for blurry and duplicate images
- Improve progress dashboard and status counters
- Add optional Azure Blob Storage backup
- Add AI-based image categorisation or captioning
- Add tests for hashing, file handling, and logging modules

## Author

**Ingsam Angdembe**  
BSc (Hons) Computing Systems  
Interested in Python, Applied AI, Computer Vision, Cloud, and Photography Technology.
