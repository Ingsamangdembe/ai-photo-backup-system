# app/ui/app_ui.py
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox


class BackupUI:
    """UI builder. No backup logic here."""

    def __init__(self, root: tk.Tk, controller):
        self.root = root
        self.c = controller  # controller = BackupApp (core)

        self.root.title("AI-Enhanced Photo Backup System")
        self.root.geometry("1120x760")
        self.root.minsize(1040, 720)

        self.style = ttk.Style(self.root)
        try:
            self.style.theme_use("clam")
        except Exception:
            pass

        self.dark_mode_var = tk.BooleanVar(value=False)

        self._build_menu()

        outer = ttk.Frame(root, padding=14)
        outer.pack(fill="both", expand=True)

        header = ttk.Frame(outer)
        header.pack(fill="x")

        ttk.Label(header, text="AI-Enhanced Photo Backup System", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Local backup + exact duplicate detection (SHA-256) + quality checks (blur / near-duplicate).",
            style="Sub.TLabel"
        ).pack(anchor="w", pady=(4, 10))

        self.nb = ttk.Notebook(outer)
        self.nb.pack(fill="both", expand=True)

        self.tab_dashboard = ttk.Frame(self.nb, padding=10)
        self.tab_log = ttk.Frame(self.nb, padding=10)
        self.tab_settings = ttk.Frame(self.nb, padding=10)

        self.nb.add(self.tab_dashboard, text="Dashboard")
        self.nb.add(self.tab_log, text="Activity Log")
        self.nb.add(self.tab_settings, text="Settings")

        self._build_dashboard(self.tab_dashboard)
        self._build_activity_log(self.tab_log)
        self._build_settings(self.tab_settings)

        self.apply_theme()

        self.root.protocol("WM_DELETE_WINDOW", self.c.on_close)

    # ---------- Theme ----------
    def apply_theme(self):
        dark = bool(self.dark_mode_var.get())

        if dark:
            bg = "#15181e"
            card = "#1c212b"
            fg = "#e9eef7"
            muted = "#b7c0ce"
            entry_bg = "#10131a"
            tree_bg = "#10131a"
            tree_sel = "#2a3550"
            btn_bg = "#232a36"
            accent = "#2f6fed"
        else:
            bg = "#f2f2f2"
            card = "#f2f2f2"
            fg = "#111111"
            muted = "#333333"
            entry_bg = "#ffffff"
            tree_bg = "#ffffff"
            tree_sel = "#d7e3ff"
            btn_bg = "#f6f6f6"
            accent = "#2f6fed"

        self.root.configure(bg=bg)
        s = self.style

        s.configure("TFrame", background=bg)
        s.configure("Card.TLabelframe", background=card)
        s.configure("Card.TLabelframe.Label", background=card, foreground=fg, font=("Segoe UI", 10, "bold"))

        s.configure("Title.TLabel", font=("Segoe UI", 22, "bold"), background=bg, foreground=fg)
        s.configure("Sub.TLabel", font=("Segoe UI", 10), background=bg, foreground=muted)

        s.configure("TLabel", background=bg, foreground=fg)
        s.configure("Status.TLabel", font=("Segoe UI", 10, "bold"), background=bg, foreground=fg)

        s.configure("TButton", font=("Segoe UI", 10), padding=(10, 6))
        s.map("TButton", background=[("active", btn_bg)], foreground=[("active", fg)])

        s.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), padding=(12, 7))
        s.map("Accent.TButton", foreground=[("active", "#ffffff")], background=[("active", accent)])

        s.configure("TNotebook", background=bg)
        s.configure("TNotebook.Tab", padding=(12, 6), font=("Segoe UI", 10, "bold"))
        s.map("TNotebook.Tab",
              background=[("selected", card), ("!selected", bg)],
              foreground=[("selected", fg), ("!selected", muted)])

        s.configure("TEntry", padding=(6, 4))
        s.map("TEntry", fieldbackground=[("!disabled", entry_bg)], foreground=[("!disabled", fg)])

        s.configure("Treeview", background=tree_bg, fieldbackground=tree_bg, foreground=fg, rowheight=22)
        s.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
        s.map("Treeview", background=[("selected", tree_sel)])

        try:
            self.log_box.configure(bg=tree_bg, fg=fg, insertbackground=fg)
        except Exception:
            pass

    def toggle_dark_mode(self):
        self.apply_theme()
        self.c.log(f"Appearance: {'Dark mode' if self.dark_mode_var.get() else 'Light mode'} enabled")

    # ---------- Menu ----------
    def _build_menu(self):
        menubar = tk.Menu(self.root)

        m_file = tk.Menu(menubar, tearoff=0)
        m_file.add_command(label="Exit", command=self.c.on_close)
        menubar.add_cascade(label="File", menu=m_file)

        m_tools = tk.Menu(menubar, tearoff=0)
        m_tools.add_command(label="Test Copy (manual)", command=self.c.manual_copy_test)
        m_tools.add_separator()
        m_tools.add_command(label="Clear Backup Folder", command=self.c.clear_backup_folder)
        m_tools.add_command(label="Reset DB (duplicate index)", command=self.c.reset_db)
        m_tools.add_separator()
        m_tools.add_command(label="Export Near-Duplicates CSV…", command=lambda: self.c.export_filtered_csv("near_dup"))
        m_tools.add_command(label="Export Blurry Images CSV…", command=lambda: self.c.export_filtered_csv("blurry"))
        m_tools.add_command(label="Export Skipped SHA Duplicates CSV…", command=lambda: self.c.export_filtered_csv("sha_skipped"))
        m_tools.add_separator()
        m_tools.add_command(label="Open CSV Log Location", command=self.c.open_csv_location)
        m_tools.add_command(label="Open DB Location", command=self.c.open_db_location)
        menubar.add_cascade(label="Tools", menu=m_tools)

        m_help = tk.Menu(menubar, tearoff=0)
        m_help.add_command(label="About", command=lambda: messagebox.showinfo(
            "About",
            "AI-Enhanced Photo Backup System\n\n"
            "• Exact duplicate detection: SHA-256\n"
            "• Near-duplicate flag: pHash distance\n"
            "• Quality check: Blur score (Laplacian variance)\n"
            "• Persistent index: SQLite\n"
        ))
        menubar.add_cascade(label="Help", menu=m_help)

        self.root.config(menu=menubar)

    # ---------- Builders ----------
    def _build_dashboard(self, parent: ttk.Frame):
        top = ttk.Frame(parent)
        top.pack(fill="x")

        folders = ttk.Labelframe(top, text="Folders", style="Card.TLabelframe", padding=10)
        folders.pack(side="left", fill="both", expand=True, padx=(0, 10))

        ttk.Label(folders, text="Source Folder:").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=(0, 8))
        ttk.Entry(folders, textvariable=self.c.source_path, width=78).grid(row=0, column=1, sticky="we", pady=(0, 8))
        ttk.Button(folders, text="Browse", command=self.c.select_source).grid(row=0, column=2, padx=(10, 0), pady=(0, 8))

        ttk.Label(folders, text="Backup Folder:").grid(row=1, column=0, sticky="w", padx=(0, 8))
        ttk.Entry(folders, textvariable=self.c.backup_path, width=78).grid(row=1, column=1, sticky="we")
        ttk.Button(folders, text="Browse", command=self.c.select_backup).grid(row=1, column=2, padx=(10, 0))

        folders.columnconfigure(1, weight=1)

        controls = ttk.Labelframe(top, text="Controls", style="Card.TLabelframe", padding=10)
        controls.pack(side="right", fill="y")

        ttk.Button(controls, text="Start Monitoring", style="Accent.TButton", command=self.c.start_monitor)\
            .grid(row=0, column=0, columnspan=2, sticky="we", pady=(0, 8))
        ttk.Button(controls, text="Stop", command=self.c.stop_monitor).grid(row=1, column=0, sticky="we", padx=(0, 8))
        ttk.Button(controls, text="Test Copy (manual)", command=self.c.manual_copy_test).grid(row=1, column=1, sticky="we")
        ttk.Button(controls, text="Clear Backup", command=self.c.clear_backup_folder).grid(row=2, column=0, sticky="we", padx=(0, 8), pady=(8, 0))
        ttk.Button(controls, text="Reset DB", command=self.c.reset_db).grid(row=2, column=1, sticky="we", pady=(8, 0))

        controls.columnconfigure(0, weight=1)
        controls.columnconfigure(1, weight=1)

        status = ttk.Labelframe(parent, text="Status", style="Card.TLabelframe", padding=10)
        status.pack(fill="x", pady=(12, 10))

        ttk.Label(status, textvariable=self.c.current_file_var, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        ttk.Label(status, textvariable=self.c.current_stage_var).pack(anchor="w", pady=(2, 8))

        self.progress = ttk.Progressbar(status, orient="horizontal", mode="determinate",
                                        variable=self.c.progress_var, maximum=1.0)
        self.progress.pack(fill="x")
        self.c._wire_progressbar(self.progress)

        ttk.Label(status, textvariable=self.c.status_var, style="Status.TLabel").pack(anchor="w", pady=(8, 0))

        recent = ttk.Labelframe(parent, text="Recent Files", style="Card.TLabelframe", padding=10)
        recent.pack(fill="both", expand=True)

        cols = ("time", "filename", "action", "sha_dup", "near_dup", "blur", "note")
        self.recent_tree = ttk.Treeview(recent, columns=cols, show="headings", height=12)
        self.c._wire_recent_tree(self.recent_tree)

        headings = {
            "time": "Time", "filename": "File", "action": "Action",
            "sha_dup": "SHA dup", "near_dup": "Near dup", "blur": "Blur", "note": "Note"
        }
        for k, v in headings.items():
            self.recent_tree.heading(k, text=v)

        self.recent_tree.column("time", width=90, anchor="w")
        self.recent_tree.column("filename", width=360, anchor="w")
        self.recent_tree.column("action", width=170, anchor="w")
        self.recent_tree.column("sha_dup", width=80, anchor="center")
        self.recent_tree.column("near_dup", width=90, anchor="center")
        self.recent_tree.column("blur", width=90, anchor="e")
        self.recent_tree.column("note", width=240, anchor="w")

        yscroll = ttk.Scrollbar(recent, orient="vertical", command=self.recent_tree.yview)
        self.recent_tree.configure(yscrollcommand=yscroll.set)
        self.recent_tree.pack(side="left", fill="both", expand=True)
        yscroll.pack(side="right", fill="y")

        self.recent_tree.bind("<Button-3>", self.c._recent_context_menu)

    def _build_activity_log(self, parent: ttk.Frame):
        ttk.Label(parent, text="Activity Log", font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(0, 8))
        self.log_box = scrolledtext.ScrolledText(parent, width=120, height=26)
        self.log_box.pack(fill="both", expand=True)
        self.c._wire_log_box(self.log_box)

    def _build_settings(self, parent: ttk.Frame):
        app_card = ttk.Labelframe(parent, text="Appearance", style="Card.TLabelframe", padding=12)
        app_card.pack(fill="x", pady=(0, 12))

        ttk.Checkbutton(app_card, text="Enable Dark Mode", variable=self.dark_mode_var, command=self.toggle_dark_mode)\
            .pack(anchor="w")

        card = ttk.Labelframe(parent, text="AI / Quality Settings", style="Card.TLabelframe", padding=12)
        card.pack(fill="x")

        row = ttk.Frame(card)
        row.pack(fill="x")

        ttk.Label(row, text="Near-duplicate threshold (pHash distance):").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=(0, 10))
        ttk.Spinbox(row, from_=1, to=64, textvariable=self.c.phash_spin, width=8).grid(row=0, column=1, sticky="w", pady=(0, 10))

        ttk.Label(row, text="Blur threshold (lower = more blurry):").grid(row=1, column=0, sticky="w", padx=(0, 10))
        ttk.Spinbox(row, from_=1, to=5000, increment=1, textvariable=self.c.blur_spin, width=8).grid(row=1, column=1, sticky="w")

        ttk.Button(row, text="Apply", style="Accent.TButton", command=self.c.apply_settings)\
            .grid(row=0, column=2, rowspan=2, padx=(18, 0), sticky="ns")

        row.columnconfigure(0, weight=1)

        ttk.Label(parent,
                  text="Tip: Tune thresholds after testing. Blur scores vary by camera + ISO. pHash threshold ~8–14 is common.",
                  style="Sub.TLabel").pack(anchor="w", pady=(10, 0))