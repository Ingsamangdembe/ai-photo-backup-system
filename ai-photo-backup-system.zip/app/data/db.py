# app/data/db.py
import sqlite3
import threading
from datetime import datetime


class BackupDB:
    """Stores SHA256 so duplicates are detected across restarts."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.lock = threading.Lock()
        self._init_db()

    def _connect(self):
        return sqlite3.connect(self.db_path, check_same_thread=False)

    def _init_db(self):
        with self.lock:
            con = self._connect()
            cur = con.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS files (
                    sha256 TEXT PRIMARY KEY,
                    filename TEXT,
                    ext TEXT,
                    src_path TEXT,
                    size_bytes INTEGER,
                    mtime REAL,
                    is_raw INTEGER,
                    backed_up_at TEXT,
                    last_status TEXT,
                    last_error TEXT
                )
            """)
            cur.execute("CREATE INDEX IF NOT EXISTS idx_filename ON files(filename)")
            con.commit()
            con.close()

    def has_sha(self, sha256_hex: str) -> bool:
        with self.lock:
            con = self._connect()
            cur = con.cursor()
            cur.execute("SELECT 1 FROM files WHERE sha256=? LIMIT 1", (sha256_hex,))
            row = cur.fetchone()
            con.close()
            return row is not None

    def upsert(
        self,
        sha256_hex: str,
        filename: str,
        ext: str,
        src_path: str,
        size_bytes: int,
        mtime: float,
        is_raw: int,
        status: str,
        err: str = ""
    ) -> None:
        with self.lock:
            con = self._connect()
            cur = con.cursor()
            cur.execute("""
                INSERT INTO files (sha256, filename, ext, src_path, size_bytes, mtime, is_raw, backed_up_at, last_status, last_error)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(sha256) DO UPDATE SET
                    filename=excluded.filename,
                    ext=excluded.ext,
                    src_path=excluded.src_path,
                    size_bytes=excluded.size_bytes,
                    mtime=excluded.mtime,
                    is_raw=excluded.is_raw,
                    backed_up_at=excluded.backed_up_at,
                    last_status=excluded.last_status,
                    last_error=excluded.last_error
            """, (
                sha256_hex, filename, ext, src_path, size_bytes, mtime, is_raw,
                datetime.now().isoformat(timespec="seconds"),
                status, err
            ))
            con.commit()
            con.close()

    def reset(self):
        with self.lock:
            con = self._connect()
            cur = con.cursor()
            cur.execute("DROP TABLE IF EXISTS files")
            con.commit()
            con.close()
        self._init_db()