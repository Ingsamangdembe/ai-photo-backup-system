# app/data/csv_logger.py
import csv
import os
import threading
import time


class CSVLogger:
    def __init__(self, csv_path: str):
        self.csv_path = csv_path
        self.lock = threading.Lock()
        self.ensure_header()

    def ensure_header(self):
        if not os.path.exists(self.csv_path):
            with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "timestamp", "filename", "ext",
                    "sha_duplicate", "near_duplicate", "phash_dist",
                    "blur_score", "action", "processing_ms", "error"
                ])

    def write_row(self, filename, ext, sha_dup, near_dup, dist, blur, action, ms, err=""):
        with self.lock:
            with open(self.csv_path, "a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow([
                    time.strftime("%Y-%m-%d %H:%M:%S"),
                    filename, ext,
                    sha_dup, near_dup, dist,
                    blur, action, ms, err
                ])