# app/core/backup_app.py
import os
import time
import shutil
import threading
import queue
import hashlib
import tkinter as tk
from tkinter import filedialog, messagebox
import csv
import heapq
from typing import Optional

from watchdog.observers import Observer
from PIL import Image
import imagehash
import cv2

from app.utils.constants import RAW_EXTS
from app.utils.system import ensure_dir, open_in_file_explorer, safe_float
from app.data.db import BackupDB
from app.data.csv_logger import CSVLogger
from app.core.watchdog_handler import BackupHandler
from app.ui.app_ui import BackupUI


class BackupApp:
    """Controller: owns state + logic, UI calls into this."""

    def __init__(self, root: tk.Tk):
        self.root = root

        # State vars UI binds to
        self.source_path = tk.StringVar()
        self.backup_path = tk.StringVar()
        self.current_file_var = tk.StringVar(value="Current: (idle)")
        self.current_stage_var = tk.StringVar(value="Stage: (idle)")
        self.progress_var = tk.DoubleVar(value=0.0)
        self.status_var = tk.StringVar(value="Status: Ready")

        # Settings vars
        self.phash_threshold = 11
        self.blur_threshold = 80.0
        self.phash_spin = tk.IntVar(value=self.phash_threshold)
        self.blur_spin = tk.DoubleVar(value=self.blur_threshold)

        # Runtime
        self.observer: Optional[Observer] = None
        self.file_queue: "queue.Queue[str]" = queue.Queue(maxsize=5000)
        self.ai_queue: "queue.Queue[tuple]" = queue.Queue(maxsize=5000)

        self.pending = set()
        self.pending_lock = threading.Lock()

        self.last_seen = {}
        self.debounce_seconds = 1.2
        self.recently_handled = {}
        self.cooldown_seconds = 20.0

        self.worker_threads = []
        self.ai_threads = []
        self.worker_running = False
        self.ai_running = False

        self.db_path = os.path.join(os.getcwd(), "backup_index.db")
        self.csv_path = os.path.join(os.getcwd(), "backup_log.csv")

        self.db = BackupDB(self.db_path)
        self.csv_logger = CSVLogger(self.csv_path)

        self.ui_queue: "queue.Queue[str]" = queue.Queue()
        self.log_box = None
        self.recent_tree = None
        self.progressbar = None

        self.total_queued = 0
        self.total_done = 0
        self.total_failed = 0
        self.total_skipped = 0
        self.counter_lock = threading.Lock()

        self.dup_skip_count = 0
        self.dup_skip_lock = threading.Lock()

        self.phash_db = []  # (phash, filename)

        self.retry_heap = []
        self.retry_lock = threading.Lock()
        self.retry_running = True
        self.retry_thread = threading.Thread(target=self._retry_scheduler_loop, daemon=True)
        self.retry_thread.start()

        self.progress_max = 1
        self.max_recent_rows = 250

        # Build UI
        self.ui = BackupUI(root, self)

        # Start draining UI logs
        self.root.after(100, self._drain_ui_queue)

        # Initial log
        self.log("Ready. Select Source + Backup folders.")
        self.log(f"CSV log: {self.csv_path}")
        self.log(f"DB index: {self.db_path}")

    # ---------- wiring points from UI ----------
    def _wire_log_box(self, log_box):
        self.log_box = log_box

    def _wire_recent_tree(self, tree):
        self.recent_tree = tree

    def _wire_progressbar(self, pb):
        self.progressbar = pb

    # ---------- UI safe setters ----------
    def log(self, msg: str):
        ts = time.strftime("%H:%M:%S")
        self.ui_queue.put(f"[{ts}] {msg}")

    def _drain_ui_queue(self):
        try:
            while True:
                line = self.ui_queue.get_nowait()
                if self.log_box:
                    self.log_box.insert(tk.END, line + "\n")
                    self.log_box.see(tk.END)
        except queue.Empty:
            pass
        self.root.after(100, self._drain_ui_queue)

    def set_status(self):
        with self.counter_lock:
            qsize = self.file_queue.qsize()
            text = f"Status: queued={qsize} | done={self.total_done} | skipped={self.total_skipped} | failed={self.total_failed}"
        self.root.after(0, lambda: self.status_var.set(text))

    def update_current(self, filename: str, stage: str):
        self.root.after(0, lambda: self.current_file_var.set(f"Current: {filename}"))
        self.root.after(0, lambda: self.current_stage_var.set(f"Stage: {stage}"))

    def set_progress(self, value: float, maximum: float):
        def _do():
            if self.progressbar:
                self.progressbar["maximum"] = maximum
            self.progress_var.set(value)
        self.root.after(0, _do)

    def add_recent_row(self, filename, action, sha_dup, near_dup, blur, note=""):
        def _insert():
            if not self.recent_tree:
                return
            t = time.strftime("%H:%M:%S")
            self.recent_tree.insert("", 0, values=(t, filename, action, sha_dup, near_dup, blur, note))
            children = self.recent_tree.get_children("")
            if len(children) > self.max_recent_rows:
                for iid in children[self.max_recent_rows:]:
                    self.recent_tree.delete(iid)
        self.root.after(0, _insert)

    # ---------- right-click menu ----------
    def _recent_context_menu(self, event):
        if not self.recent_tree:
            return
        item = self.recent_tree.identify_row(event.y)
        if not item:
            return
        self.recent_tree.selection_set(item)
        values = self.recent_tree.item(item, "values")
        if not values:
            return
        filename = values[1]

        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="Copy filename", command=lambda: self._copy_to_clipboard(filename))
        menu.tk_popup(event.x_root, event.y_root)

    def _copy_to_clipboard(self, text: str):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
        except Exception:
            pass

    # ---------- menu helpers ----------
    def open_csv_location(self):
        open_in_file_explorer(os.path.dirname(self.csv_path))

    def open_db_location(self):
        open_in_file_explorer(os.path.dirname(self.db_path))

    # ---------- settings ----------
    def apply_settings(self):
        try:
            self.phash_threshold = int(self.phash_spin.get())
            self.blur_threshold = float(self.blur_spin.get())
            self.log(f"Settings applied: pHash_threshold={self.phash_threshold}, blur_threshold={self.blur_threshold}")
        except Exception as e:
            messagebox.showerror("Settings Error", f"Could not apply settings: {e}")

    # ---------- folder pickers ----------
    def select_source(self):
        folder = filedialog.askdirectory()
        if folder:
            self.source_path.set(folder)
            self.log(f"Source set to: {folder}")

    def select_backup(self):
        folder = filedialog.askdirectory()
        if folder:
            self.backup_path.set(folder)
            self.log(f"Backup set to: {folder}")

    # ---------- export ----------
    def export_filtered_csv(self, mode: str):
        if not os.path.exists(self.csv_path):
            messagebox.showinfo("Export", "CSV log not found yet. Run the system first.")
            return

        default_name = {
            "near_dup": "export_near_duplicates.csv",
            "blurry": "export_blurry_images.csv",
            "sha_skipped": "export_sha_duplicates_skipped.csv",
        }.get(mode, "export.csv")

        save_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            initialfile=default_name,
            filetypes=[("CSV Files", "*.csv")],
            title="Export CSV"
        )
        if not save_path:
            return

        rows_out = 0
        try:
            with open(self.csv_path, "r", newline="", encoding="utf-8") as fin:
                reader = csv.DictReader(fin)
                fieldnames = reader.fieldnames or [
                    "timestamp", "filename", "ext",
                    "sha_duplicate", "near_duplicate", "phash_dist",
                    "blur_score", "action", "processing_ms", "error"
                ]

                with open(save_path, "w", newline="", encoding="utf-8") as fout:
                    writer = csv.DictWriter(fout, fieldnames=fieldnames)
                    writer.writeheader()

                    for r in reader:
                        action = (r.get("action") or "").strip()
                        near_dup = (r.get("near_duplicate") or "").strip().lower()
                        sha_dup = (r.get("sha_duplicate") or "").strip().lower()
                        blur = safe_float(r.get("blur_score"))

                        keep = False
                        if mode == "near_dup":
                            keep = (action == "ai_checked" and near_dup == "yes")
                        elif mode == "blurry":
                            keep = (action == "ai_checked" and blur is not None and blur < float(self.blur_threshold))
                        elif mode == "sha_skipped":
                            keep = (action == "skipped_sha_duplicate" or sha_dup == "yes")

                        if keep:
                            writer.writerow(r)
                            rows_out += 1

            self.log(f"Exported {rows_out} row(s) → {save_path}")
            messagebox.showinfo("Export Complete", f"Exported {rows_out} row(s).\n\n{save_path}")
        except Exception as e:
            messagebox.showerror("Export Error", f"Could not export: {e}")

    # ---------- scanning ----------
    def scan_existing_images(self):
        src = self.source_path.get().strip()
        if not src or not os.path.isdir(src):
            self.log("Scan failed: Source folder invalid.")
            return

        count = 0
        for root_dir, _, files in os.walk(src):
            for name in files:
                full_path = os.path.join(root_dir, name)
                if full_path.lower().endswith((".jpg", ".jpeg", ".png", ".arw", ".cr2", ".cr3", ".nef", ".raf", ".dng")):
                    self.enqueue_file(full_path, silent=True)
                    count += 1

        self.progress_max = max(1, count)
        self.set_progress(0, self.progress_max)
        self.log(f"Initial scan queued {count} existing file(s).")
        self.set_status()

    # ---------- backup path mirroring ----------
    def build_backup_path(self, src_path: str) -> str:
        src_root = os.path.abspath(self.source_path.get().strip())
        dst_root = os.path.abspath(self.backup_path.get().strip())
        if not src_root or not dst_root:
            return os.path.join(dst_root, os.path.basename(src_path))
        try:
            rel = os.path.relpath(os.path.abspath(src_path), src_root)
            if rel.startswith(".."):
                return os.path.join(dst_root, os.path.basename(src_path))
            return os.path.join(dst_root, rel)
        except Exception:
            return os.path.join(dst_root, os.path.basename(src_path))

    # ---------- hashing + AI ----------
    def compute_sha256(self, file_path: str, chunk_size: int = 1024 * 1024) -> str:
        h = hashlib.sha256()
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    def compute_phash(self, file_path: str):
        with Image.open(file_path) as img:
            return imagehash.phash(img)

    def is_near_duplicate(self, phash_value):
        for existing_hash, existing_name in self.phash_db:
            dist = phash_value - existing_hash
            if dist <= self.phash_threshold:
                return True, existing_name, dist
        return False, None, None

    def blur_score(self, file_path: str) -> float:
        img = cv2.imread(file_path)
        if img is None:
            raise ValueError("Could not read image (cv2.imread returned None)")
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        return float(cv2.Laplacian(gray, cv2.CV_64F).var())

    # ---------- retries ----------
    def _schedule_retry(self, path: str, attempts: int, reason: str):
        delays = [30, 60, 120, 240, 300, 600, 900]
        delay = delays[min(attempts, len(delays) - 1)]
        next_time = time.time() + delay
        with self.retry_lock:
            heapq.heappush(self.retry_heap, (next_time, attempts + 1, path, reason))
        self.log(f"Deferred retry scheduled: {os.path.basename(path)} in {delay}s (attempt {attempts + 1})")

    def _retry_scheduler_loop(self):
        while self.retry_running:
            item = None
            with self.retry_lock:
                if self.retry_heap and self.retry_heap[0][0] <= time.time():
                    item = heapq.heappop(self.retry_heap)

            if item:
                _, attempts, path, reason = item
                if attempts >= 8:
                    self.log(f"Gave up after retries: {os.path.basename(path)} (reason={reason})")
                    with self.counter_lock:
                        self.total_skipped += 1
                    with self.pending_lock:
                        self.pending.discard(path)
                    self.set_status()
                    continue

                if os.path.exists(path):
                    with self.pending_lock:
                        self.pending.discard(path)
                    self.enqueue_file(path, silent=True)
                else:
                    self.log(f"Deferred retry dropped (missing): {os.path.basename(path)}")

            time.sleep(0.3)

    # ---------- queue ----------
    def enqueue_file(self, path: str, silent: bool = False):
        now = time.time()

        last_evt = self.last_seen.get(path, 0)
        if now - last_evt < self.debounce_seconds:
            return
        self.last_seen[path] = now

        last_handled = self.recently_handled.get(path, 0)
        if now - last_handled < self.cooldown_seconds:
            return

        with self.pending_lock:
            if path in self.pending:
                return
            self.pending.add(path)

        try:
            self.file_queue.put_nowait(path)
            with self.counter_lock:
                self.total_queued += 1
            if not silent:
                self.log(f"Queued: {os.path.basename(path)}")
            self.set_status()
        except queue.Full:
            self.log("Queue is full. Try again or increase maxsize.")
            with self.pending_lock:
                self.pending.discard(path)

    # ---------- monitoring ----------
    def start_monitor(self):
        src = self.source_path.get().strip()
        dst = self.backup_path.get().strip()

        if not src or not dst:
            self.log("Please select both folders first.")
            return
        if os.path.abspath(src) == os.path.abspath(dst):
            self.log("Source and Backup folders must be different.")
            return
        if not os.path.isdir(src):
            self.log("Source folder is invalid.")
            return

        ensure_dir(dst)

        if not self.worker_running:
            self.worker_running = True
            self.worker_threads = []
            for i in range(3):
                t = threading.Thread(target=self.worker_loop, args=(i,), daemon=True)
                t.start()
                self.worker_threads.append(t)
            self.log("Background IO workers started (3 threads).")

        if not self.ai_running:
            self.ai_running = True
            self.ai_threads = []
            t = threading.Thread(target=self.ai_loop, daemon=True)
            t.start()
            self.ai_threads.append(t)
            self.log("Background AI worker started (1 thread).")

        if self.observer is None:
            handler = BackupHandler(self)
            self.observer = Observer()
            self.observer.schedule(handler, src, recursive=True)
            self.observer.start()
            self.log("Monitoring started... (watching for new files)")
            self.scan_existing_images()
        else:
            self.log("Monitoring is already running.")

    def stop_monitor(self):
        self.retry_running = False

        if self.observer is not None:
            try:
                self.observer.stop()
                self.observer.join(timeout=3)
            except Exception:
                pass
            self.observer = None
            self.log("Monitoring stopped.")

        if self.worker_running:
            self.worker_running = False
            for _ in self.worker_threads:
                self.file_queue.put("__STOP__")
            self.log("Stopping IO workers...")

        if self.ai_running:
            self.ai_running = False
            for _ in self.ai_threads:
                self.ai_queue.put(("__STOP__",))
            self.log("Stopping AI worker...")

        self.set_status()

    # ---------- readiness ----------
    def wait_until_ready(self, src_path: str, max_wait_seconds: int) -> bool:
        deadline = time.time() + max_wait_seconds
        last_size = -1
        stable_hits = 0

        while time.time() < deadline:
            try:
                if not os.path.exists(src_path):
                    time.sleep(0.2)
                    continue

                size = os.path.getsize(src_path)
                if size == last_size and size > 0:
                    stable_hits += 1
                else:
                    stable_hits = 0
                last_size = size

                if stable_hits < 4:
                    time.sleep(0.25)
                    continue

                with open(src_path, "rb"):
                    pass
                return True

            except PermissionError:
                time.sleep(0.6)
            except OSError:
                time.sleep(0.3)

        return False

    # ---------- IO worker ----------
    def worker_loop(self, worker_id: int):
        while True:
            item = self.file_queue.get()
            if item == "__STOP__":
                break

            path = item
            start_t = time.perf_counter()

            filename = os.path.basename(path)
            ext = os.path.splitext(filename)[1].lower()
            is_raw = ext in RAW_EXTS

            sha_dup = "no"
            near_dup = "no"
            phash_dist = ""
            blur_val = ""
            action = ""
            err_msg = ""

            self.update_current(filename, "Waiting / lock check")

            dst_folder = self.backup_path.get().strip()
            if not dst_folder:
                action = "skipped_no_backup_folder"
                self._finish_one(path, filename, ext, sha_dup, near_dup, phash_dist, blur_val, action, start_t, err_msg)
                continue

            dst_path = self.build_backup_path(path)
            ensure_dir(os.path.dirname(dst_path))

            ready = self.wait_until_ready(path, max_wait_seconds=90 if is_raw else 30)
            if not ready:
                action = "deferred_locked"
                self.log(f"Locked too long (deferred): {filename}")
                ms = int((time.perf_counter() - start_t) * 1000)
                self.csv_logger.write_row(filename, ext, sha_dup, near_dup, phash_dist, blur_val, action, ms, "locked_wait_timeout")
                self.add_recent_row(filename, action, sha_dup, near_dup, blur_val, "locked_wait_timeout")
                self._schedule_retry(path, attempts=0, reason="locked_wait_timeout")
                with self.pending_lock:
                    self.pending.discard(path)
                self.set_status()
                continue

            self.update_current(filename, "Hashing (SHA-256)")

            try:
                file_hash = self.compute_sha256(path)
            except Exception as e:
                action = "skipped_hash_failed"
                err_msg = str(e)
                self.log(f"Hashing failed for {filename}: {e}")
                self._finish_one(path, filename, ext, sha_dup, near_dup, phash_dist, blur_val, action, start_t, err_msg)
                continue

            if self.db.has_sha(file_hash):
                sha_dup = "yes"
                action = "skipped_sha_duplicate"

                with self.dup_skip_lock:
                    self.dup_skip_count += 1
                    c = self.dup_skip_count
                if c <= 5 or c % 10 == 0:
                    self.log(f"Duplicates skipped so far: {c} (latest: {filename})")

                self._finish_one(path, filename, ext, sha_dup, near_dup, phash_dist, blur_val, action, start_t, err_msg)
                continue

            self.update_current(filename, "Copying (atomic)")

            try:
                tmp_path = dst_path + ".tmp"
                shutil.copy2(path, tmp_path)
                os.replace(tmp_path, dst_path)

                try:
                    st = os.stat(path)
                    self.db.upsert(
                        sha256_hex=file_hash,
                        filename=filename,
                        ext=ext,
                        src_path=path,
                        size_bytes=int(st.st_size),
                        mtime=float(st.st_mtime),
                        is_raw=1 if is_raw else 0,
                        status="backed_up",
                        err=""
                    )
                except Exception as e:
                    self.log(f"DB update failed for {filename}: {e}")

                action = "backed_up"
                self.log(f"Backed up: {filename}")
                self.add_recent_row(filename, action, sha_dup, near_dup, blur_val, "")

                with self.counter_lock:
                    self.total_done += 1

                if not is_raw:
                    self.ai_queue.put((path, filename, ext))

            except PermissionError as e:
                action = "deferred_copy_locked"
                err_msg = str(e)
                self.log(f"Backup deferred (still locked): {filename}")
                ms = int((time.perf_counter() - start_t) * 1000)
                self.csv_logger.write_row(filename, ext, sha_dup, near_dup, phash_dist, blur_val, action, ms, err_msg)
                self.add_recent_row(filename, action, sha_dup, near_dup, blur_val, "copy locked")
                self._schedule_retry(path, attempts=0, reason="copy_permission_error")
                with self.pending_lock:
                    self.pending.discard(path)
                self.set_status()
                continue

            except Exception as e:
                action = "failed_copy_error"
                err_msg = str(e)
                self.log(f"Backup failed for {filename}: {e}")
                self.add_recent_row(filename, action, sha_dup, near_dup, blur_val, err_msg)
                with self.counter_lock:
                    self.total_failed += 1

            ms = int((time.perf_counter() - start_t) * 1000)
            self.csv_logger.write_row(filename, ext, sha_dup, near_dup, phash_dist, blur_val, action, ms, err_msg)

            self.recently_handled[path] = time.time()
            with self.pending_lock:
                self.pending.discard(path)

            with self.counter_lock:
                done = self.total_done + self.total_skipped + self.total_failed
            self.set_progress(done, self.progress_max)
            self.set_status()

    # ---------- AI worker ----------
    def ai_loop(self):
        while True:
            item = self.ai_queue.get()
            if item and item[0] == "__STOP__":
                break

            path, filename, ext = item
            self.update_current(filename, "AI checks (pHash + blur)")

            start_t = time.perf_counter()
            near_dup = "no"
            phash_dist = ""
            blur_val = ""
            err_msg = ""

            try:
                ph = self.compute_phash(path)
                near, matched_name, dist = self.is_near_duplicate(ph)
                if near:
                    near_dup = "yes"
                    phash_dist = str(dist)
                    self.log(f"Near-duplicate FLAG: {filename} ~ {matched_name} (dist={dist})")
                self.phash_db.append((ph, filename))
            except Exception as e:
                err_msg = str(e)
                self.log(f"pHash failed for {filename}: {e}")

            note = ""
            try:
                score = self.blur_score(path)
                blur_val = f"{score:.1f}"
                if score < self.blur_threshold:
                    note = "blurry"
                    self.log(f"Low quality (blurry): {filename} (score={score:.1f})")
                else:
                    self.log(f"Sharpness OK: {filename} (score={score:.1f})")
            except Exception as e:
                note = "blur fail"
                self.log(f"Blur check failed for {filename}: {e}")

            if near_dup == "yes":
                note = (note + " | " if note else "") + f"near-dup dist={phash_dist}"

            self.add_recent_row(filename, "ai_checked", "no", near_dup, blur_val, note)

            ms = int((time.perf_counter() - start_t) * 1000)
            self.csv_logger.write_row(filename, ext, "no", near_dup, phash_dist, blur_val, "ai_checked", ms, err_msg)

    def _finish_one(self, path, filename, ext, sha_dup, near_dup, phash_dist, blur_val, action, start_t, err_msg):
        ms = int((time.perf_counter() - start_t) * 1000)
        self.csv_logger.write_row(filename, ext, sha_dup, near_dup, phash_dist, blur_val, action, ms, err_msg)
        self.add_recent_row(filename, action, sha_dup, near_dup, blur_val, err_msg)

        if action.startswith("skipped"):
            with self.counter_lock:
                self.total_skipped += 1
        else:
            with self.counter_lock:
                self.total_failed += 1

        self.recently_handled[path] = time.time()
        with self.pending_lock:
            self.pending.discard(path)

        with self.counter_lock:
            done = self.total_done + self.total_skipped + self.total_failed
        self.set_progress(done, self.progress_max)
        self.set_status()

    # ---------- manual copy ----------
    def manual_copy_test(self):
        dst_root = self.backup_path.get().strip()
        if not dst_root:
            messagebox.showinfo("Select Backup Folder", "Please select a Backup folder first.")
            return

        file_path = filedialog.askopenfilename(
            filetypes=[("Photos", "*.jpg;*.jpeg;*.png;*.arw;*.cr2;*.cr3;*.nef;*.raf;*.dng")]
        )
        if not file_path:
            return

        dst_path = self.build_backup_path(file_path)
        ensure_dir(os.path.dirname(dst_path))

        if not self.wait_until_ready(file_path, max_wait_seconds=12):
            self.log("Manual copy failed: file locked too long (close Lightroom/Explorer preview).")
            return

        try:
            tmp_path = dst_path + ".tmp"
            shutil.copy2(file_path, tmp_path)
            os.replace(tmp_path, dst_path)
            self.log(f"Manual copy OK: {os.path.basename(file_path)}")
            self.add_recent_row(os.path.basename(file_path), "manual_copy", "no", "no", "", "")
        except Exception as e:
            self.log(f"Manual copy failed: {e}")
            self.add_recent_row(os.path.basename(file_path), "manual_copy_failed", "no", "no", "", str(e))

    # ---------- clear/reset ----------
    def clear_backup_folder(self):
        dst = self.backup_path.get().strip()
        if not dst or not os.path.isdir(dst):
            messagebox.showinfo("Clear Backup", "Backup folder is not set or does not exist.")
            return

        if not messagebox.askyesno("Clear Backup", "Delete ALL files inside the selected backup folder?\n\nThis cannot be undone."):
            return

        deleted = 0
        failed = 0
        for root_dir, _, files in os.walk(dst):
            for name in files:
                try:
                    os.remove(os.path.join(root_dir, name))
                    deleted += 1
                except Exception:
                    failed += 1

        self.log(f"Cleared backup folder. Deleted {deleted} file(s). Failed {failed} file(s).")
        self.add_recent_row("(backup folder)", "cleared_backup", "no", "no", "", f"deleted={deleted}, failed={failed}")

    def reset_db(self):
        if not messagebox.askyesno("Reset DB", "Reset the duplicate index database?\n\nThis will forget what has been backed up before."):
            return
        try:
            self.db.reset()
            self.log("DB reset completed.")
            self.add_recent_row("(db)", "reset_db", "no", "no", "", "")
        except Exception as e:
            self.log(f"DB reset failed: {e}")
            self.add_recent_row("(db)", "reset_db_failed", "no", "no", "", str(e))

    # ---------- close ----------
    def on_close(self):
        self.stop_monitor()
        self.root.after(200, self.root.destroy)