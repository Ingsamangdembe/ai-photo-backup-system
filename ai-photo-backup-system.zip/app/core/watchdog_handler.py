# app/core/watchdog_handler.py
from watchdog.events import FileSystemEventHandler
from app.utils.system import is_image


class BackupHandler(FileSystemEventHandler):
    def __init__(self, app):
        self.app = app

    def on_created(self, event):
        self._maybe_queue(event)

    def on_modified(self, event):
        self._maybe_queue(event)

    def _maybe_queue(self, event):
        if event.is_directory:
            return
        src = event.src_path
        if not is_image(src):
            return
        self.app.enqueue_file(src)