# app/main.py
import tkinter as tk
from app.core.backup_app import BackupApp

def main():
    root = tk.Tk()
    BackupApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()