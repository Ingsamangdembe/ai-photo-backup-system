# app/utils/system.py
import os
import subprocess
import sys
from typing import Optional

from .constants import IMAGE_EXTS


def is_image(path: str) -> bool:
    return path.lower().endswith(IMAGE_EXTS)


def ensure_dir(path: str) -> None:
    if path:
        os.makedirs(path, exist_ok=True)


def open_in_file_explorer(path: str) -> None:
    try:
        path = os.path.abspath(path)
        if os.name == "nt":
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.run(["open", path], check=False)
        else:
            subprocess.run(["xdg-open", path], check=False)
    except Exception:
        pass


def safe_float(x) -> Optional[float]:
    try:
        if x is None:
            return None
        s = str(x).strip()
        if s == "":
            return None
        return float(s)
    except Exception:
        return None