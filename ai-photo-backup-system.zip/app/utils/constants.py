# app/utils/constants.py

IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".arw", ".cr2", ".cr3", ".nef", ".raf", ".dng")
RAW_EXTS   = (".arw", ".cr2", ".cr3", ".nef", ".raf", ".dng")